function hide(element) {
    element.remove();
    } 

c = 0
function adicionarLike() {
  c += 1;
  botao.innerHTML = `${c} likes`;  
} 

c = 0
function adicionarLike2() {
  c += 1;
  bota.innerHTML = `${c} likes`;  
} 
function login(element) {
  element.innerText = "Logout"
    
}
